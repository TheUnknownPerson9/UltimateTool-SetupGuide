this app is for creating symlinks watch this video for in depth explanation: https://www.youtube.com/watch?v=RDH5IuyPJtk

in short it is like shortcuts but apps will redirect through it instead of indexing the shortcuts
IN EVER SHORTER TERMS:
it makes shortcuts on crack