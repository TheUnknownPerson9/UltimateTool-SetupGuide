if you have winrar installed, go click on the start or windows menu, type in "WinRAR", open file location, open file location again on the shortcut, 
and paste the rarreg.key file in there, overrite if you have to
