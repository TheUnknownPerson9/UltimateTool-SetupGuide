﻿# Support

## Contact

- E-mail: [Mouri_Naruto@Outlook.com](mailto:Mouri_Naruto@Outlook.com)

## Community

- [GitHub Issues](https://github.com/M2Team/NSudo/issues)
- [My Digital Life](https://forums.mydigitallife.net/threads/59268)
- [QQ Group](https://shang.qq.com/wpa/qunwpa?idkey=ac879ff5e88f85115597a9ec5f3dbbf28a6b84d7352e2fe03b7cbacf58bb6d53)
