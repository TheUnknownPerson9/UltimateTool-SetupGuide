﻿/*
 * PROJECT:   M2-Team Common Library
 * FILE:      M2MessageDialogResource.h
 * PURPOSE:   Definition for the message dialog resource
 *
 * LICENSE:   The MIT License
 *
 * DEVELOPER: Mouri_Naruto (Mouri_Naruto AT Outlook.com)
 */

#define IDD_MESSAGE_DIALOG              105
#define IDC_MESSAGE_DIALOG_EDIT         1003
