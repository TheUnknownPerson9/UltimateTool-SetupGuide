﻿/*
 * PROJECT:   M2-Team Common Library
 * FILE:      M2.Base.cpp
 * PURPOSE:   Implementation for M2-Team Common Library Base C++ Wrapper
 *
 * LICENSE:   The MIT License
 *
 * DEVELOPER: Mouri_Naruto (Mouri_Naruto AT Outlook.com)
 */

#include "M2.Base.h"
