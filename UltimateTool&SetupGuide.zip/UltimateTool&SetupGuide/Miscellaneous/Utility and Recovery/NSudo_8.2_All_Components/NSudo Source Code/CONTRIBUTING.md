﻿The content moved to [Readme.md](Readme.md#contributing-to-nsudo)
